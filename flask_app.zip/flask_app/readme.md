activate the env - conda activate <env_name>

install the libraries -- pip install flask